<x-app-layout>
    <x-slot name="title">Edit Project</x-slot>

    <div class="max-w-2xl">
        <div class="mb-6">
            <a href="{{ route('projects.show', $project) }}" class="theme-text-secondary theme-hover-primary text-sm">← Back to project</a>
            <div class="flex items-center gap-2 mt-1">
                <h1 class="text-2xl font-semibold theme-text-primary">Edit Project</h1>
                <button type="button" @click="$dispatch('toggle-distribution')" class="p-1.5 rounded-lg theme-text-muted theme-hover-primary theme-sidebar-link-hover transition" title="Distribution settings">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                </button>
            </div>
        </div>
        <div class="theme-card-bg-only theme-border border rounded-2xl p-6">
            <form action="{{ route('projects.update', $project) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                @include('projects._form', ['project' => $project, 'clients' => $clients])
                <div class="mt-6 flex gap-3">
                    <button type="submit" class="px-4 py-2.5 rounded-xl theme-btn-primary font-medium">Update</button>
                    <a href="{{ route('projects.show', $project) }}" class="px-4 py-2.5 rounded-xl theme-btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>
