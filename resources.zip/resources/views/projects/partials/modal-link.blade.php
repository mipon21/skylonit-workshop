<div x-show="linkModal" x-cloak class="fixed inset-0 z-50 overflow-y-auto" aria-modal="true">
    <div class="flex min-h-full items-center justify-center p-4 max-md:p-0 max-md:items-stretch">
        <div x-show="linkModal" x-transition class="fixed inset-0 bg-black/60 backdrop-blur-sm" @click="linkModal = false"></div>
        <div x-show="linkModal" x-transition class="relative w-full max-w-md theme-bg-tertiary border theme-border rounded-2xl shadow-xl p-6 max-md:max-w-none max-md:max-h-full max-md:rounded-none max-md:border-0">
            <h2 class="text-lg font-semibold theme-text-primary mb-4">Add Link / APK</h2>
            <form action="{{ route('projects.links.store', $project) }}" method="POST" enctype="multipart/form-data" x-data="{ linkType: '{{ old('link_type', 'url') }}' }">
                @csrf
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium theme-text-secondary mb-1">Type *</label>
                        <select name="link_type" x-model="linkType" class="w-full rounded-xl theme-input-bg border theme-border theme-text-primary px-4 py-2.5 theme-input-focus">
                            <option value="url">Live URL</option>
                            <option value="apk">APK Download</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium theme-text-secondary mb-1">Label *</label>
                        <input type="text" name="label" value="{{ old('label') }}" required class="w-full rounded-xl theme-input-bg border theme-border theme-text-primary px-4 py-2.5 theme-input-focus" placeholder="e.g. Admin Panel, Staging, App v1.0">
                        @error('label')<p class="text-red-400 text-xs mt-1">{{ $message }}</p>@enderror
                    </div>
                    <template x-if="linkType === 'url'">
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium theme-text-secondary mb-1">URL *</label>
                                <input type="url" name="url" value="{{ old('url') }}" class="w-full rounded-xl theme-input-bg border theme-border theme-text-primary px-4 py-2.5 theme-input-focus" placeholder="https://...">
                                @error('url')<p class="text-red-400 text-xs mt-1">{{ $message }}</p>@enderror
                            </div>
                            <div>
                                <label class="block text-sm font-medium theme-text-secondary mb-1">Login username (optional)</label>
                                <input type="text" name="login_username" value="{{ old('login_username') }}" class="w-full rounded-xl theme-input-bg border theme-border theme-text-primary px-4 py-2.5 theme-input-focus">
                            </div>
                            <div>
                                <label class="block text-sm font-medium theme-text-secondary mb-1">Login password (optional)</label>
                                <input type="text" name="login_password" value="{{ old('login_password') }}" class="w-full rounded-xl theme-input-bg border theme-border theme-text-primary px-4 py-2.5 theme-input-focus">
                            </div>
                        </div>
                    </template>
                    <template x-if="linkType === 'apk'">
                        <div>
                            <label class="block text-sm font-medium theme-text-secondary mb-1">APK file *</label>
                            <input type="file" name="apk_file" accept=".apk" class="w-full rounded-xl theme-input-bg border theme-border theme-text-primary px-4 py-2.5 file:mr-3 file:py-1.5 file:rounded-lg file:border-0 file:theme-bg-tertiary file:theme-text-secondary text-sm">
                            <p class="theme-text-muted text-xs mt-1">Max 500MB.</p>
                            @error('apk_file')<p class="text-red-400 text-xs mt-1">{{ $message }}</p>@enderror
                        </div>
                    </template>
                    <div class="pt-2 border-t theme-border">
                        <label class="block text-sm font-medium theme-text-secondary mb-1">Who can see this link?</label>
                        @if($isDeveloper ?? false)
                            <input type="hidden" name="visibility" value="{{ \App\Models\ProjectLink::VISIBILITY_CLIENT }}">
                            <select disabled class="w-full rounded-xl theme-bg-tertiary/80 border theme-border theme-text-secondary px-4 py-2.5 cursor-not-allowed">
                                <option value="{{ \App\Models\ProjectLink::VISIBILITY_CLIENT }}" selected>Admin & Client (no guest)</option>
                            </select>
                            <p class="theme-text-muted text-xs mt-1">Developers can only add links visible to Admin & Client.</p>
                        @else
                            <select name="visibility" class="w-full rounded-xl theme-input-bg border theme-border theme-text-primary px-4 py-2.5 theme-input-focus">
                                @foreach(\App\Models\ProjectLink::visibilityLabels() as $value => $label)
                                    <option value="{{ $value }}" {{ old('visibility', 'client') === $value ? 'selected' : '' }}>{{ $label }}</option>
                                @endforeach
                            </select>
                            <p class="theme-text-muted text-xs mt-1">Admin always sees all. Choose who else can see this link or APK.</p>
                        @endif
                    </div>
                    @if(($isDeveloper ?? false) || ($isClient ?? false))
                    <input type="hidden" name="send_email" value="1">
                    <p class="theme-text-muted text-xs pt-2 border-t theme-border">Email notification will be sent to the client.</p>
                    @else
                    <div class="pt-2 border-t theme-border">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="send_email" value="1" {{ old('send_email', false) ? 'checked' : '' }} class="rounded theme-border theme-input-bg text-orange-500 focus:ring-orange-500">
                            <span class="text-sm font-medium theme-text-secondary">Send Email Notification?</span>
                        </label>
                    </div>
                    @endif
                </div>
                <div class="mt-6 flex justify-end gap-3">
                    <button type="button" @click="linkModal = false" class="px-4 py-2.5 rounded-xl border theme-border theme-text-secondary theme-sidebar-link-hover">Cancel</button>
                    <button type="submit" class="px-4 py-2.5 rounded-xl theme-btn-primary font-medium">Add Link</button>
                </div>
            </form>
        </div>
    </div>
</div>
